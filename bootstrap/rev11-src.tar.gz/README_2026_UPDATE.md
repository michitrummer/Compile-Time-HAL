# 2026 Cube GPIO benchmark update

## Version baseline

- STM32CubeL4 package tag: **v1.18.2**
- STM32L4 HAL/LL driver tag: **v1.13.6**
- Target: **STM32L433RC / Cortex-M4**

## Changes

1. `CubeMXHAL/CubeMXHAL.ioc` now selects `STM32Cube FW_L4 V1.18.2`.
2. The benchmark-relevant HAL GPIO behavior was updated to the v1.13.6 implementation:
   - generic `HAL_GPIO_Init` restored; the old benchmark had manually commented out generic paths,
   - `HAL_GPIO_ReadPin` and `HAL_GPIO_WritePin` retained as the official callable HAL APIs.
3. Added `CubeMXLL`, using the matching Cube LL APIs:
   - `LL_AHB2_GRP1_EnableClock`,
   - `LL_GPIO_Init`,
   - inline `LL_GPIO_IsInputPinSet`, `LL_GPIO_SetOutputPin`, and `LL_GPIO_ResetOutputPin`.
4. Both Cube variants preserve the original ninefold initialization/access benchmark structure.

## Scope note

This is a GPIO-benchmark update, not a byte-for-byte replacement of every unused middleware and peripheral driver in the original generated project. The compiled GPIO paths were aligned with the tagged v1.13.6 HAL/LL behavior and versioned explicitly. This keeps the comparison focused and avoids including unrelated UART/I2C/etc. code in the analysis.

The reproducible instruction analysis is delivered separately in `instruction-analysis-v2.zip`.

## Compile-time HAL and benchmark revision 3

The compile-time HAL now takes mode, pull and speed as non-type template
parameters. `Led` and `Switch` therefore construct their pins without passing
runtime configuration arguments. Local static objects were removed from the
benchmark entry points.

Register blocks now use plain volatile integer members, are accessed through a
`registers()` function, and are protected by compile-time size and offset
checks. See `InstructionAnalysis/README.md` for the three rebuilt examples and
instruction counts.
